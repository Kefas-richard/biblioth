from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import engine, Base, SessionLocal
from app.routers import books, auth, admin, emprunts
from app.models.utilisateur import Utilisateur
from passlib.context import CryptContext
import logging

# Configuration des logs pour un meilleur suivi
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Projet Bibliothèque")

# ✅ Configuration améliorée de CORS pour éviter les erreurs `OPTIONS 400`
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 🔥 Autoriser toutes les origines (tu peux préciser ton frontend : http://127.0.0.1:5500)
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],  # 🔥 Permet toutes les méthodes (OPTIONS inclus)
    allow_headers=["Authorization", "Content-Type", "Accept"]  # 🔥 Ajout de `Accept` pour éviter les blocages
)

# ✅ Création automatique d'un administrateur s'il n'existe pas
def create_admin():
    db = SessionLocal()
    admin_email = "admin@example.com"
    admin_password = "admin123"

    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    hashed_password = pwd_context.hash(admin_password)

    try:
        if not db.query(Utilisateur).filter(Utilisateur.email == admin_email).first():
            admin = Utilisateur(email=admin_email, mot_de_passe=hashed_password)
            db.add(admin)
            db.commit()
            db.refresh(admin)
            logger.info("✅ Admin créé avec succès !")
        else:
            logger.info("ℹ Admin déjà existant.")
    except Exception as e:
        logger.error(f"❌ Erreur lors de la création de l'admin : {e}")
    finally:
        db.close()

create_admin()  # Exécution automatique au démarrage

# ✅ Ajout des routes API
app.include_router(auth.router)
app.include_router(books.router)
app.include_router(admin.router)
app.include_router(emprunts.router)

@app.get("/")
def root():
    return {"message": "Bienvenue dans la bibliothèque"}

@app.get("/ping")
def health_check():
    return {"status": "✅ Serveur opérationnel"}
