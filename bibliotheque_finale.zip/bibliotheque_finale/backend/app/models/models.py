from sqlalchemy import Column, Integer, String, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from app.database import Base
from datetime import datetime

from sqlalchemy import Column, Integer, String
from app.database import Base

class Livre(Base):
    __tablename__ = "livres"

    id = Column(Integer, primary_key=True, index=True)
    titre = Column(String, nullable=False)
    auteur = Column(String, nullable=False)

class Utilisateur(Base):
    __tablename__ = "utilisateurs"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    mot_de_passe = Column(String, nullable=False)

    emprunts = relationship("Emprunt", back_populates="utilisateur", cascade="all, delete-orphan")

class Emprunt(Base):
    __tablename__ = "emprunts"
    
    id = Column(Integer, primary_key=True, index=True)
    livre_id = Column(Integer, ForeignKey("livres.id", ondelete="CASCADE"), nullable=False)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False)
    date_emprunt = Column(DateTime, default=datetime.utcnow, nullable=False)
    date_retour = Column(DateTime, nullable=True)

    livre = relationship("Livre", back_populates="emprunts")
    utilisateur = relationship("Utilisateur", back_populates="emprunts")
