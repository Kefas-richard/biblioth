from fastapi import APIRouter

router = APIRouter()

@router.get("/admin/stats")
def get_stats():
    return {"message": "📊 Voici les statistiques de la bibliothèque"}
