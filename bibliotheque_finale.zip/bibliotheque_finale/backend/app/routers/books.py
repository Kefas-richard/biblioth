from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models import Livre
from pydantic import BaseModel

router = APIRouter()

# ✅ Définition du modèle LivreSchema AVANT son utilisation
class LivreSchema(BaseModel):
    titre: str
    auteur: str

# ✅ Fonction pour récupérer la session de base de données
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ✅ Route GET : Récupérer tous les livres avec gestion des erreurs
@router.get("/books")
def get_books(db: Session = Depends(get_db)):
    try:
        books = db.query(Livre).all()
        if not books:
            raise HTTPException(status_code=404, detail="📚 Aucun livre trouvé.")
        return books
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"❌ Erreur serveur : {str(e)}")

# ✅ Route POST : Ajouter un livre avec gestion des erreurs
@router.post("/books")
def add_book(book: LivreSchema, db: Session = Depends(get_db)):  # 🔥 Utilisation correcte du modèle
    try:
        new_book = Livre(titre=book.titre, auteur=book.auteur)
        db.add(new_book)
        db.commit()
        db.refresh(new_book)
        return {"message": "✅ Livre ajouté avec succès", "livre": new_book}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"❌ Erreur d'ajout du livre : {str(e)}")


# ✅ Route OPTIONS : Répondre aux pré-requêtes du navigateur
@router.options("/books")
def handle_options(response: Response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Authorization, Content-Type, Accept"
    return response

# ✅ Route GET /livres pour récupérer les livres
@router.get("/livres")  
def get_livres(db: Session = Depends(get_db)):
    return db.query(Livre).all()
