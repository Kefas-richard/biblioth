from fastapi import APIRouter

router = APIRouter()

@router.get("/emprunts")
def get_emprunts():
    return {"message": "📜 Liste des emprunts en cours"}
