﻿// Authentification
document.getElementById("loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
  
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
  
    try {
      const response = await fetch("http://localhost:8000/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
  
      const data = await response.json();
  
      if (response.ok) {
        localStorage.setItem("authToken", data.access_token);
        window.location.href = "dashboard.html"; // Redirection après connexion
      } else {
        document.getElementById("errorMessage").innerText = "❌ Identifiants incorrects !";
      }
    } catch (error) {
      console.error("Erreur de connexion :", error);
      document.getElementById("errorMessage").innerText = "❌ Une erreur est survenue.";
    }
  });
  