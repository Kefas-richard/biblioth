﻿document.addEventListener("DOMContentLoaded", async () => {
  const token = localStorage.getItem("authToken");
  if (!token) {
      window.location.href = "login.html";
      return;
  }

  function displayMessage(type, message) {
      const alertBox = document.createElement("div");
      alertBox.className = `alert ${type}`;
      alertBox.textContent = message;
      document.body.appendChild(alertBox);
      setTimeout(() => alertBox.remove(), 3000); // Supprime l'alerte après 3 secondes
  }

  async function loadBooks() {
    try {
        const response = await fetch("http://127.0.0.1:8000/books", {
            method: "GET",
            headers: { "Accept": "application/json" }
        });

        if (!response.ok) throw new Error(`Erreur de chargement des livres - Status: ${response.status}`);

        const books = await response.json();

        if (!Array.isArray(books)) {  // 🔥 Vérifie que `books` est un tableau
            throw new Error("❌ La réponse du serveur n'est pas un tableau !");
        }

        const booksList = document.getElementById("booksList");
        booksList.innerHTML = "";  // 🔥 Nettoie la liste avant d’ajouter les livres

        books.forEach(book => {
            let row = document.createElement("tr");
            row.innerHTML = `
                <td>${book.id}</td>
                <td>${book.titre}</td>
                <td>${book.auteur}</td>
                <td>
                    <button onclick="deleteBook(${book.id})">🗑 Supprimer</button>
                </td>
            `;
            booksList.appendChild(row);
        });

        console.log("📚 Contenu de booksList:", booksList.innerHTML);  // 🔥 Vérifie ce qui est ajouté dans le HTML
    } catch (error) {
        console.error("❌ Erreur de chargement des livres :", error);
    }
}



  async function deleteBook(id) {
      try {
          const response = await fetch(`http://127.0.0.1:8000/books/${id}`, {
              method: "DELETE",
              mode: "cors",  // 🔥 Ajout de `cors`
              headers: { 
                  Authorization: `Bearer ${token}`,
                  "Content-Type": "application/json",
                  "Accept": "application/json"
              },
          });

          if (!response.ok) throw new Error(`Impossible de supprimer le livre - Status: ${response.status}`);

          await response.json();
          loadBooks(); // Recharge la liste après suppression
          displayMessage("success", "✅ Livre supprimé !");
      } catch (error) {
          console.error("❌ Impossible de supprimer le livre :", error);
          displayMessage("error", "❌ Erreur lors de la suppression !");
      }
  }

  document.getElementById("addBookBtn").addEventListener("click", async () => {
      const titre = prompt("Titre du livre :");
      const auteur = prompt("Auteur du livre :");

      if (titre && auteur) {
          try {
              const response = await fetch("http://127.0.0.1:8000/books", {
                  method: "POST",
                  mode: "cors",  // 🔥 Ajout de `cors`
                  headers: {
                      "Content-Type": "application/json",
                      Authorization: `Bearer ${token}`,
                      "Accept": "application/json"  
                  },
                  body: JSON.stringify({ titre, auteur })
              });

              if (!response.ok) throw new Error(`Impossible d'ajouter le livre - Status: ${response.status}`);

              await response.json();
              loadBooks();
              displayMessage("success", "✅ Livre ajouté avec succès !");
          } catch (error) {
              console.error("❌ Impossible d'ajouter le livre :", error);
              displayMessage("error", "❌ Erreur lors de l'ajout !");
          }
      }
  });

  loadBooks();
});
