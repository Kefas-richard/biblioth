﻿// Dashboard JS
document.addEventListener("DOMContentLoaded", async () => {
    const token = localStorage.getItem("authToken");
    if (!token) {
      window.location.href = "login.html";
      return;
    }
  
    try {
      const response = await fetch("http://localhost:8000/admin/stats", {
        headers: { Authorization: `Bearer ${token}` },
      });
  
      const data = await response.json();
      document.getElementById("livres").innerText = data.livres;
      document.getElementById("membres").innerText = data.membres;
      document.getElementById("emprunts").innerText = data.emprunts;
    } catch (error) {
      console.error("❌ Erreur de récupération des statistiques :", error);
    }
  });
  