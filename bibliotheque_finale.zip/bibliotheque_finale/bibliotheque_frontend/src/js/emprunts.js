﻿// Emprunts JS
document.addEventListener("DOMContentLoaded", async () => {
    const token = localStorage.getItem("authToken");
    if (!token) {
      window.location.href = "login.html";
      return;
    }
  
    async function loadEmprunts() {
      try {
        const response = await fetch("http://localhost:8000/emprunts", {
          headers: { Authorization: `Bearer ${token}` },
        });
  
        const emprunts = await response.json();
        const empruntsList = document.getElementById("empruntsList");
        empruntsList.innerHTML = "";
  
        emprunts.forEach(emprunt => {
          empruntsList.innerHTML += `
            <tr>
              <td>${emprunt.id}</td>
              <td>${emprunt.livre}</td>
              <td>${emprunt.emprunteur}</td>
              <td>${emprunt.date_emprunt}</td>
              <td>${emprunt.date_retour}</td>
            </tr>
          `;
        });
      } catch (error) {
        console.error("❌ Erreur de chargement des emprunts :", error);
      }
    }
  
    loadEmprunts();
  });
  